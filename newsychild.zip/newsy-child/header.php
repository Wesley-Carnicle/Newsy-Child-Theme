<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=yes' />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<script type="text/javascript" src="//imasdk.googleapis.com/js/sdkloader/ima3.js"></script>

	<?php wp_head(); ?>
	
	<!--Video styling dependencies-->
		<link href="https://vjs.zencdn.net/7.4.1/video-js.css" rel="stylesheet">
	
	<!--Video styling dependencies-->
		<link href="https://vjs.zencdn.net/7.4.1/video-js.css" rel="stylesheet">
		<link rel="stylesheet" href="https://searkweather.com/wp-content/themes/newsy-child/videojs/js/ima-sdk-plugin/videojs.ads.css">
		<link rel="stylesheet" href="https://searkweather.com/wp-content/themes/newsy-child/videojs/js/ima-sdk-plugin/videojs.ima.css">
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
	<div class="ak-main-bg-wrap"></div>
	<?php do_action( 'newsy_main_before' ); ?>

	<!-- The Main Wrapper
	============================================= -->
	<div class="ak-main-wrap">

		<?php do_action( 'newsy_header_before' ); ?>

		<?php get_template_part( 'views/header' ); ?>

		<?php do_action( 'newsy_header_after' ); ?>
