<?php

// Dev mode enabled
// Use this for uncompressed custom css codes
//if ( ! defined( 'AK_DEV_MODE' ) ) {
//	define( 'AK_DEV_MODE', TRUE );
//}
add_action( 'ak-framework/setup/after', 'newsy_child_init' );

function newsy_child_init() {
	add_filter( 'ak_thumbnail_image', 'get_the_image_plugin_thumbnail_image', 5, 4 );
	add_filter( 'ak_background_image', 'get_the_image_plugin_thumbnail_image', 5, 3 );
}

function get_the_image_plugin_thumbnail_image( $output, $id, $size, $auto_wrap = false ) {
	if ( ! has_post_thumbnail( $id ) ) {
		if ( function_exists( 'get_the_image' ) ) {
			$result = get_the_image(
				array(
					'post_id' => $id,
					'scan'    => true,
					'size'    => $size,
					'format'  => 'array',
					'echo'    => false,
					'cache'   => true,
					'order'   => array( 'scan' ),
				)
			);
			//	return $result;

			if ( ! empty( $result ) ) {

				$style  = '';
	
				$src    = isset( $result['src'] ) ? $result['src'] : '';
				$alt    = isset( $result['alt'] ) ? $result['alt'] : '';
				$height = isset( $result['height'] ) ? $result['height'] : end(explode( 'x', $size ));
				$width  = isset( $result['width'] ) ? $result['width'] : str_replace( array( 'newsy_', 'x', $height ), array('', '', ''), $size );
				$width = intval($width) > 0 ? intval($width) : 75 ;
				$height = intval($height) > 0 ? intval($height) : 75 ;
			
				if ( isset( $width ) ) {
				$percentage = round( $height / $width * 100, 3 );
				$style      = ' style="padding-bottom:' . $percentage . '%"';
				}

				$thumbnail  = "<div class=\"ak-featured-thumb lazy-thumb size-auto \"{$style}>";
				$thumbnail .= '<img class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="' . $src . '">';
				$thumbnail .= '</div>';

				remove_filter( 'ak_thumbnail_image', array( \Ak\Support\Image::get_instance(), 'thumbnail_image' ), 11 );
				remove_filter( 'ak_background_image', array( \Ak\Support\Image::get_instance(), 'background_image' ), 11 );

				return $thumbnail;
			}
		}
	}

	add_filter( 'ak_thumbnail_image', array( \Ak\Support\Image::get_instance(), 'thumbnail_image' ), 11, 4 );
	add_filter( 'ak_background_image', array( \Ak\Support\Image::get_instance(), 'background_image' ), 11, 3 );

	return $output;
}

// Protect Site from Malicious Requests

global $user_ID; if($user_ID) {
    if(!current_user_can('administrator')) {
        if (strlen($_SERVER['REQUEST_URI']) > 255 ||
            stripos($_SERVER['REQUEST_URI'], "eval(") ||
            stripos($_SERVER['REQUEST_URI'], "CONCAT") ||
            stripos($_SERVER['REQUEST_URI'], "UNION+SELECT") ||
            stripos($_SERVER['REQUEST_URI'], "base64")) {
                @header("HTTP/1.1 414 Request-URI Too Long");
                @header("Status: 414 Request-URI Too Long");
                @header("Connection: Close");
                @exit;
        }
    }
}


//function wp_smartwp_scripts_method() {
    //wp_enqueue_script( 'my-custom-script', get_stylesheet_directory_uri() . '/js/your_custom_script.js', array( 'jquery' ), true );
//}
//add_action( 'wp_enqueue_scripts', 'wp_smartwp_scripts_method' );


add_filter('comments_template', 'legacy_comments');
function legacy_comments($file) {
	if(!function_exists('wp_list_comments')) : // WP 2.7-only check
		$file = TEMPLATEPATH . '/legacy-comments.php';
	endif;
	return $file;
}