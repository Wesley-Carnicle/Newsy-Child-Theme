<div class="ak-bar-item ak-header-mobile-logo">
	<div class="ak-logo-wrap ak-logo-<?php echo newsy_get_option( 'mobile_logo_type', 'image' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php echo newsy_generate_logo( 'mobile' ); ?>
		</a>
	</div>
</div>
