<div class="ak-bar-item ak-footer-logo">
	<div class="ak-logo-wrap ak-logo-<?php echo newsy_get_option( 'footer_logo_type', 'image' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php echo newsy_generate_logo( 'footer' ); ?>
		</a>
	</div>
</div>
