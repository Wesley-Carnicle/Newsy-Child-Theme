<div class="ak-bar-item ak-header-button ak-header-button1">
	<?php newsy_generate_button( 'header_button1' ); ?>
</div>
