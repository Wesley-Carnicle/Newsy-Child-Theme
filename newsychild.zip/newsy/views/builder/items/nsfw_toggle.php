<div class="ak-bar-item ak-nsfw-mode">
	<div class="ak-toggle-container">
		<input type="checkbox" class="ak-nsfw-toggle">
		<span class="slider round"></span>
	</div>
</div>
