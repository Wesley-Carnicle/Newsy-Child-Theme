<div class="ak-bar-item ak-footer-ad2">
	<?php newsy_get_ad( 'footer_ad2' ); ?>
</div>
