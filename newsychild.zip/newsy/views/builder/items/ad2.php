<div class="ak-bar-item ak-header-ad2">
	<?php newsy_get_ad( 'header_ad2' ); ?>
</div>
