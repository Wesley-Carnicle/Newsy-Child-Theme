<div class="ak-bar-item ak-header-button ak-header-button2">
	<?php newsy_generate_button( 'header_button2' ); ?>
</div>
