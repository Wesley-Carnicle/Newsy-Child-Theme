<div class="ak-bar-item ak-footer-button1">
	<?php newsy_generate_button( 'footer_button1' ); ?>
</div>
