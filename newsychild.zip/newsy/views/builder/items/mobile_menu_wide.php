<div class="ak-bar-item ak-mobile-bar-menu-container">
	<?php
	ak_nav_menu(
		array(
			'theme_location' => 'mobile-menu',
			'menu_class'     => 'ak-mobile-bar-menu ak-menu-wide ak-menu-style-6',
			'echo'           => true,
		)
	);
	?>
</div>
