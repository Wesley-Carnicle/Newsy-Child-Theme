<div class="ak-bar-item ak-post-sticky-share">
<div class="ak-share-container ak-share-style-1">
</div>
</div>
