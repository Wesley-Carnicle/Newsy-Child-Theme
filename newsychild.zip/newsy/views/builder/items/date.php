<div class="ak-bar-item ak-header-date">
	<i class="fa fa-clock-o"></i>
	<span>
		<?php echo date_i18n( newsy_get_option( 'topbar_date_format', 'l, F j, Y' ), current_time( 'timestamp' ) ); ?>
	</span>
</div>
