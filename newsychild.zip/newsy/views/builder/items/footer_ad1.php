<div class="ak-bar-item ak-footer-ad1">
	<?php newsy_get_ad( 'footer_ad1' ); ?>
</div>
