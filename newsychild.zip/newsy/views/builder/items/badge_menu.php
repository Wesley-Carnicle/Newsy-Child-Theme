<?php

if ( function_exists( 'newsy_reaction_get_badge_menu' ) ) {
	?>
	<div class="ak-bar-item ak-header-badge-menu">
		<?php
		newsy_reaction_get_badge_menu();
		?>
	</div>
	<?php
}
