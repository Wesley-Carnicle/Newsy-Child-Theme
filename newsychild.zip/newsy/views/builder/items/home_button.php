<div class="ak-bar-item ak-header-home-button">
	<a href="<?php echo esc_url( home_url() ); ?>" class="ak-header-icon-btn ak-header-home-btn">
	<?php echo ak_get_icon( newsy_get_option( 'header_home_icon', 'fa-home' ) ); ?>
	</a>
</div>
