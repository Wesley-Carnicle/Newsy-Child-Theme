<div class="ak-bar-item ak-dark-mode">
	<div class="ak-toggle-container">
		<label for="dark_mode"><span class="screen-reader-text">Dark mode</span></label>
		<input id="dark_mode" type="checkbox" class="ak-dark-mode-toggle" <?php echo newsy_is_dark_mode() ? 'checked' : ''; ?>>
		<span class="slider round"></span>
	</div>
</div>
