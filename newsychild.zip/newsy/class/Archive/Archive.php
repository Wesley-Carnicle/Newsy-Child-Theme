<?php

namespace Newsy\Archive;

/**
 * Archive template class.
 */
class Archive extends ArchiveAbstract {
	public $template_id = 'archive';

	public $default_grid_style = 'hide';
}
