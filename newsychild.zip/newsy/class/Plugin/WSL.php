<?php

namespace Newsy\Plugin;

/**
 * Newsy WordPress Social Login plugin compatibility handler.
 */
class WSL {

	/**
	 * @var WSL
	 */
	private static $instance;

	/**
	 * @return WSL
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Newsy_bbPress constructor.
	 */
	public function __construct() {
		$this->hook();
	}

	/**
	 * Callback: adds some code change to bbPress and other simple things.
	 *
	 * Filter: init
	 */
	public function hook() {
		// do not work if Newsy Social Login plugin is active.
		if ( defined( 'NEWSY_SOCIAL_LOGIN_PATH' ) ) {
			return;
		}

		add_action( 'admin_notices', array( $this, 'render_wsl_warning' ) );

		// do not work if page is wp-login page.
		if ( ! has_action( 'login_init' ) ) {
			add_filter( 'wsl_render_auth_widget_alter_provider_icon_markup', array( $this, 'render_wsl_get_button' ), 10, 3 );
		}

		add_action( 'newsy_login_form_before', array( $this, 'render_social_login_providers' ) );
	}

	public function render_wsl_warning() {
		$class   = 'notice notice-error is-dismissible';
		$message = 'Due to a security issue with the WordPress Social Login plugin, we have discontinued support for it. We recommend switching to the Newsy Social Login plugin. You can enable it on the Newsy > Install Plugins page and configure your options at Newsy > Social Login Options.		';

		printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
	}

	/**
	 * Get social login providers urls.
	 *
	 * Supported plugins:
	 * http://miled.github.io/wordpress-social-login/
	 *
	 *
	 * @since 1.8.0
	 *
	 * @return array
	 */
	public function get_social_login_providers( $providers = array() ) {
		if ( ! defined( 'WORDPRESS_SOCIAL_LOGIN_ABS_PATH' ) ) {
			return $providers;
		}

		global $WORDPRESS_SOCIAL_LOGIN_PROVIDERS_CONFIG;

		if ( empty( $WORDPRESS_SOCIAL_LOGIN_PROVIDERS_CONFIG ) || ! is_array( $WORDPRESS_SOCIAL_LOGIN_PROVIDERS_CONFIG ) ) {
			return $providers;
		}

		$current_url = home_url( add_query_arg( false, false ) );

		$login_url = add_query_arg(
			array(
				'action'      => 'wordpress_social_authenticate',
				'mode'        => 'login',
				'redirect_to' => urlencode( $current_url ),
			),
			home_url( 'wp-login.php', 'login_post' )
		);

		$use_popup = function_exists( 'wp_is_mobile' ) && wp_is_mobile() ? 2 : get_option( 'wsl_settings_use_popup' );

		foreach ( $WORDPRESS_SOCIAL_LOGIN_PROVIDERS_CONFIG as $provider ) {
			$provider_id = isset( $provider['provider_id'] ) ? $provider['provider_id'] : '';
			$is_enable   = get_option( 'wsl_settings_' . $provider_id . '_enabled' );

			if ( ! $is_enable ) {
				continue;
			}

			$provider_url = add_query_arg( 'provider', $provider_id, $login_url );
			$provider_url = apply_filters( 'wsl_render_auth_widget_alter_authenticate_url', $provider_url, $provider_id, 'login', $current_url, $use_popup );

			$providers[ $provider_id ] = $provider_url;
		}

		return $providers;
	}

	/**
	 * Used to change codes of WSL plugin to make it high compatible with newsy.
	 *
	 * @param      $provider_id
	 * @param      $provider_name
	 * @param      $authenticate_url
	 * @param bool $full
	 */
	public function render_wsl_get_button( $provider_id, $provider_name, $authenticate_url, $full = true ) {
		$provider_id_lower = strtolower( $provider_id );

		$icon = '<i class="ak-icon fa fa-' . $provider_id_lower . '" ></i>';
		?>
		<a rel="nofollow" href="<?php echo esc_url( $authenticate_url ); ?>"
			data-provider="<?php echo esc_attr( $provider_id ); ?>" class="ak-social-login-btn <?php echo esc_attr( $provider_id_lower ), ' ', ! empty( $icon ) ? 'with-icon' : ''; ?>">
				<?php
				echo wp_kses( $icon, ak_trans_allowed_html() );
				?>
				<span>
				<?php
				if ( $full ) {
					echo sprintf( newsy_get_translation( 'Login With %s', 'newsy', 'login_with' ), ucfirst( $provider_name ) );
				} else {
					echo esc_html( $provider_id );
				}
				?>
				</span>
		</a>
		<?php
	}

	/**
	 * Get social login providers urls.
	 *
	 * @return array
	 */
	public function render_social_login_providers() {
		$social_login = $this->get_social_login_providers();
		if ( $social_login ) {
			?>
			<div class="login-field social-login-buttons clearfix">
				<div class="social-login-buttons-list full-width">
				<?php
				foreach ( $social_login as $site_id => $url ) {
					$this->render_wsl_get_button( $site_id, $site_id, $url );
				}
				?>
				</div>
				<div class="or-wrapper">
					<span class="or-text"><?php newsy_echo_translation( 'Or', 'newsy', 'login_or' ); ?></span>
				</div>
			</div>
			<?php
		}
	}
}
