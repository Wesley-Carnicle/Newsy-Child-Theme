<?php
namespace Newsy\Page;

use Newsy\TemplateAbstract;

/**
 * BuddyPress template class.
 */
class BuddyPress extends TemplateAbstract {
	public $template_id = 'buddypress';
}
